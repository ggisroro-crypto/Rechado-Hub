# Rechado Hub — proyecto Android (base 0.2)

Rechado Hub es una adaptación en desarrollo de una app Android nativa basada en [Next Player](https://github.com/anilbeesetti/nextplayer), un reproductor de video abierto escrito en Kotlin. La base original está licenciada bajo GNU GPL v3; se conserva `LICENSE` y deben mantenerse los avisos de copyright y obligaciones de esa licencia al redistribuir. Este proyecto no está afiliado a YouTube, Roblox, Instagram ni TikTok.

## Pantallas incluidas

- **Inicio:** feed visual de demostración con categorías y tarjetas; las tarjetas llevan a la biblioteca local de videos.
- **Videos:** conserva el selector y reproductor local de la base original, incluida reproducción de archivos locales y algunas fuentes de red compatibles.
- **Comunidad:** publicaciones, Me gusta y comentarios locales de demostración; no sincroniza con otras personas.
- **Roblox Delta:** accesos a las páginas oficiales de Roblox y Roblox Studio y zona de recursos de demostración.
- **Cuenta:** nombre visible local, foto de perfil local, restricción de siete días para editar el nombre, y acceso a preferencias.
- **Ajustes:** apariencia rojo/negro, claro u oscuro; idioma español, inglés o portugués; preferencias locales y frecuencia objetivo para anuncios.

## Cómo compilar

Se necesita Android Studio actualizado, JDK 17 o compatible con el Gradle Wrapper, Android SDK y conexión para descargar dependencias. Abre la carpeta raíz y ejecuta la tarea `assembleDebug`, o desde terminal: `./gradlew assembleDebug`.

El APK de depuración se genera en `app/build/outputs/apk/debug/`. El nombre de paquete de depuración es `com.rechado.hub.debug`. No es una compilación de lanzamiento ni debe publicarse directamente en Play Store. Para publicar se requiere revisar la licencia y las políticas de Google Play, probar la app, configurar firma propia y preparar privacidad/seguridad.

## Compilar en la nube

Incluye el workflow `.github/workflows/build-rechado-apk.yml`. Súbelo junto con todo el contenido de este proyecto a un repositorio GitHub, abre **Actions → Build Rechado Hub APK → Run workflow**, espera a que finalice y descarga el artefacto `RechadoHub-debug-APK`. Ese artefacto contiene APK de depuración para pruebas.

## Qué todavía no hace

No hay backend de cuentas, chats, seguidores ni verificación; la comunidad solo mantiene demostraciones locales. No hay feed remoto ni integración oficial de videos de YouTube. La frecuencia de anuncios guarda una preferencia, pero no hay SDK publicitario y no controla anuncios de otras apps. No se ha compilado ni probado un APK en el entorno donde se preparó este ZIP porque aquí no se encuentra instalado el Android SDK y la descarga de Gradle está bloqueada; debe ejecutarse el workflow o compilarse en Android Studio antes de instalar.

Consulta `RECHADO_HUB_CHANGELOG.md` y `PRIVACY` antes de continuar el desarrollo.
