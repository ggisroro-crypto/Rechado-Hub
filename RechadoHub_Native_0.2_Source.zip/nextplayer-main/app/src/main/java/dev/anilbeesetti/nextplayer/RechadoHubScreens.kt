package dev.anilbeesetti.nextplayer

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import coil.compose.AsyncImage
import dev.anilbeesetti.nextplayer.core.ui.R
import kotlinx.serialization.Serializable

@Serializable
data object RechadoHomeRoute : androidx.navigation3.runtime.NavKey

@Serializable
data object RechadoCommunityRoute : androidx.navigation3.runtime.NavKey

@Serializable
data object RechadoDeltaRoute : androidx.navigation3.runtime.NavKey

@Serializable
data object RechadoAccountRoute : androidx.navigation3.runtime.NavKey

@Serializable
data object RechadoPreferencesRoute : androidx.navigation3.runtime.NavKey

private data class DemoVideo(
    val title: String,
    val creator: String,
    val meta: String,
    val category: String,
    val emoji: String,
    val short: Boolean = false,
)

private val demoVideos = listOf(
    DemoVideo("Explora tus videos en Rechado Hub", "Rechado Hub", "Guía · 3:24", "Para ti", "▶️"),
    DemoVideo("Construcciones épicas en Roblox", "PixelCraft", "Gaming · 8:42", "Gaming", "🎮"),
    DemoVideo("Un minuto de creatividad", "Luna Clips", "Corto · 0:41", "Cortos", "✨", true),
    DemoVideo("Música para jugar y crear", "Modo Noche", "Música · 12:06", "Música", "🎧"),
    DemoVideo("Trucos para construir mejor", "PixelCraft", "Gaming · 6:18", "Gaming", "🧱"),
    DemoVideo("Momentos divertidos de la semana", "Comunidad RH", "Corto · 0:29", "Cortos", "😂", true),
)

@Composable
fun RechadoHomeScreen(
    onOpenVideos: () -> Unit,
    onOpenCommunity: () -> Unit,
    onOpenDelta: () -> Unit,
    onOpenAccount: () -> Unit,
) {
    var category by remember { mutableStateOf("Para ti") }
    val categories = listOf(
        "Para ti" to stringResource(R.string.rechado_category_for_you),
        "Cortos" to stringResource(R.string.rechado_category_shorts),
        "Gaming" to stringResource(R.string.rechado_category_gaming),
        "Música" to stringResource(R.string.rechado_category_music),
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BrandMark()
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("RECHADO HUB", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(stringResource(R.string.rechado_tagline), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = onOpenAccount) { Text("●  ${stringResource(R.string.rechado_profile)}") }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B080D)),
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(stringResource(R.string.rechado_hero_title), color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(7.dp))
                    Text(stringResource(R.string.rechado_hero_body), color = Color(0xFFE4C9CE), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(13.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onOpenVideos) { Text(stringResource(R.string.rechado_browse_videos)) }
                        OutlinedButton(onClick = onOpenCommunity) { Text(stringResource(R.string.rechado_community)) }
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                categories.forEach { (value, label) ->
                    FilterChip(selected = category == value, onClick = { category = value }, label = { Text(label) })
                }
            }
        }
        item {
            Text(stringResource(R.string.rechado_recommended), modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.rechado_sample_feed_note), modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(demoVideos.filter { category == "Para ti" || it.category == category }) { video ->
            VideoFeedCard(video = video, onClick = onOpenVideos)
        }
        item {
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.rechado_explore_hub), fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenDelta, modifier = Modifier.weight(1f)) { Text("🎮  Delta") }
                        OutlinedButton(onClick = onOpenAccount, modifier = Modifier.weight(1f)) { Text("⚙  ${stringResource(R.string.rechado_settings)}") }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun BrandMark() {
    Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFFFF3146), Color(0xFF720817)))),
        contentAlignment = Alignment.Center,
    ) {
        Text("R", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun VideoFeedCard(video: DemoVideo, onClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).aspectRatio(if (video.short) 1.18f else 1.78f).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF360A12), Color(0xFF15151D), Color(0xFF570C1B)))),
            contentAlignment = Alignment.Center,
        ) {
            Text(video.emoji, style = MaterialTheme.typography.displayMedium)
            Surface(modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp), shape = RoundedCornerShape(6.dp), color = Color.Black.copy(alpha = .82f)) {
                Text(video.meta.substringAfter("·").trim(), modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp), color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
            if (video.short) {
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(8.dp), shape = RoundedCornerShape(6.dp), color = Color(0xFFFF3045)) {
                    Text("CORTO", modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
            Box(modifier = Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Text(video.emoji, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(video.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(video.creator, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(video.meta, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Text("⋮", modifier = Modifier.padding(start = 6.dp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private data class DemoPost(val author: String, val text: String)

@Composable
fun RechadoCommunityScreen() {
    var composer by remember { mutableStateOf("") }
    val posts = remember {
        mutableStateListOf(
            DemoPost("@RechadoHub", "¡Bienvenido a la comunidad! Aquí podremos compartir videos, fotos e ideas."),
            DemoPost("@PixelCraft", "¿Qué juego están jugando hoy? 🎮"),
        )
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(stringResource(R.string.rechado_community), modifier = Modifier.padding(top = 20.dp, bottom = 4.dp), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        Text(stringResource(R.string.rechado_community_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = composer,
            onValueChange = { composer = it.take(500) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.rechado_write_post)) },
            minLines = 2,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Button(onClick = { if (composer.isNotBlank()) { posts.add(0, DemoPost("@Tú", composer.trim())); composer = "" } }, enabled = composer.isNotBlank()) {
                Text(stringResource(R.string.rechado_publish))
            }
        }
        Divider(Modifier.padding(vertical = 9.dp))
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(posts) { post -> CommunityPostCard(post) }
            item {
                Text(stringResource(R.string.rechado_local_only_notice), modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun CommunityPostCard(post: DemoPost) {
    var liked by remember { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }
    var commentDraft by remember { mutableStateOf("") }
    val comments = remember { mutableStateListOf<String>() }
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(14.dp)) {
            Text(post.author, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(post.text)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { liked = !liked }) { Text(if (liked) "♥ Me gusta" else "♡ Me gusta") }
                TextButton(onClick = { showComments = !showComments }) { Text("💬 Comentar${if (comments.isNotEmpty()) " (${comments.size})" else ""}") }
                TextButton(onClick = {
                    runCatching {
                        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${post.author}: ${post.text}")
                        }, context.getString(R.string.rechado_share_post)))
                    }
                }) { Text("↗ Compartir") }
            }
            if (showComments) {
                comments.forEach { reply ->
                    Text("@Tú  $reply", modifier = Modifier.padding(start = 8.dp, top = 5.dp), style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = commentDraft, onValueChange = { commentDraft = it.take(250) }, modifier = Modifier.weight(1f), placeholder = { Text(stringResource(R.string.rechado_write_comment)) }, singleLine = true)
                    TextButton(onClick = { if (commentDraft.isNotBlank()) { comments.add(commentDraft.trim()); commentDraft = "" } }, enabled = commentDraft.isNotBlank()) { Text(stringResource(R.string.rechado_send)) }
                }
            }
        }
    }
}

@Composable
fun RechadoDeltaScreen() {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Roblox Delta", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.rechado_delta_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(16.dp)) {
                Text("📁  ${stringResource(R.string.rechado_resource_library)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.rechado_delta_placeholder), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.rechado_send_parts), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { openWeb(context, "https://www.roblox.com/") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.rechado_open_roblox)) }
        OutlinedButton(onClick = { openWeb(context, "https://create.roblox.com/") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.rechado_open_studio)) }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.rechado_safety_note), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

private fun openWeb(context: android.content.Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

@Composable
fun RechadoAccountScreen(
    onOpenSettings: () -> Unit,
    onOpenMoreTools: () -> Unit,
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("rechado_hub", android.content.Context.MODE_PRIVATE) }
    var name by remember { mutableStateOf(prefs.getString("display_name", "Usuario Rechado") ?: "Usuario Rechado") }
    var draftName by remember { mutableStateOf(name) }
    var photoUri by remember { mutableStateOf(prefs.getString("profile_photo", null)) }
    var message by remember { mutableStateOf("") }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            photoUri = uri.toString()
            prefs.edit().putString("profile_photo", photoUri).apply()
        }
    }
    var lastNameChange by remember { mutableStateOf(prefs.getLong("name_changed_at", 0L)) }
    val sevenDaysMs = 7L * 24L * 60L * 60L * 1000L
    val nameChangeLocked = lastNameChange > 0L && System.currentTimeMillis() - lastNameChange < sevenDaysMs
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text(stringResource(R.string.rechado_account), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (photoUri != null) {
                AsyncImage(model = photoUri, contentDescription = stringResource(R.string.rechado_profile_photo), modifier = Modifier.size(72.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFFF3146), Color(0xFF720817)))), contentAlignment = Alignment.Center) {
                    Text(name.take(1).uppercase(), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.rechado_demo_account), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { photoPicker.launch("image/*") }) { Text(stringResource(R.string.rechado_change_photo)) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("0", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.rechado_followers), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("0", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.rechado_following), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("0", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.rechado_likes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(15.dp))
        OutlinedTextField(value = draftName, onValueChange = { draftName = it.take(24) }, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.rechado_display_name)) }, singleLine = true, enabled = !nameChangeLocked)
        Button(onClick = {
            val clean = draftName.trim()
            if (clean.isNotBlank() && clean != name) {
                name = clean
                lastNameChange = System.currentTimeMillis()
                prefs.edit().putString("display_name", clean).putLong("name_changed_at", lastNameChange).apply()
                message = context.getString(R.string.rechado_name_saved)
            } else message = context.getString(R.string.rechado_enter_new_name)
        }, modifier = Modifier.fillMaxWidth(), enabled = !nameChangeLocked) { Text(stringResource(R.string.rechado_save_name)) }
        if (nameChangeLocked) {
            Text(stringResource(R.string.rechado_name_cooldown), modifier = Modifier.padding(top = 6.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        if (message.isNotBlank()) Text(message, modifier = Modifier.padding(top = 6.dp), color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth()) { Text("⚙  ${stringResource(R.string.rechado_settings)}") }
        OutlinedButton(onClick = onOpenMoreTools, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.rechado_player_tools)) }
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(14.dp)) {
                Text(stringResource(R.string.rechado_demo_limit_title), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(stringResource(R.string.rechado_demo_limit_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = { message = context.getString(R.string.rechado_switch_account_demo) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.rechado_switch_account)) }
        TextButton(onClick = { message = context.getString(R.string.rechado_no_real_session) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.rechado_sign_out)) }
    }
}

@Composable
fun RechadoPreferencesScreen(
    theme: String,
    onThemeChange: (String) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("rechado_hub", android.content.Context.MODE_PRIVATE) }
    var lang by remember { mutableStateOf(prefs.getString("language", "es") ?: "es") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp), style = MaterialTheme.typography.headlineMedium)
            Text(stringResource(R.string.rechado_settings), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(18.dp))
        Text(stringResource(R.string.rechado_appearance), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        listOf("red" to stringResource(R.string.rechado_theme_red), "dark" to stringResource(R.string.rechado_theme_dark), "light" to stringResource(R.string.rechado_theme_light)).forEach { (value, label) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onThemeChange(value) }.padding(vertical = 12.dp, horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (theme == value) "🔘" else "⚪", modifier = Modifier.padding(end = 10.dp))
                Text(label, modifier = Modifier.weight(1f))
            }
        }
        Divider(Modifier.padding(vertical = 12.dp))
        Text(stringResource(R.string.rechado_language), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        listOf("es" to "Español", "en" to "English", "pt" to "Português").forEach { (code, label) ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                lang = code
                prefs.edit().putString("language", code).apply()
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
            }.padding(vertical = 12.dp, horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (lang == code) "🔘" else "⚪", modifier = Modifier.padding(end = 10.dp))
                Text(label)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(stringResource(R.string.rechado_extra_preferences), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.rechado_ad_frequency), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        var adFrequency by remember { mutableStateOf(prefs.getString("ad_frequency", "20") ?: "20") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("20" to stringResource(R.string.rechado_ads_20h), "24" to stringResource(R.string.rechado_ads_24h), "off" to stringResource(R.string.rechado_ads_off)).forEach { (value, label) ->
                FilterChip(selected = adFrequency == value, onClick = { adFrequency = value; prefs.edit().putString("ad_frequency", value).apply() }, label = { Text(label) })
            }
        }
        var notifications by remember { mutableStateOf(prefs.getBoolean("notifications", true)) }
        var autoplay by remember { mutableStateOf(prefs.getBoolean("autoplay", true)) }
        var privateProfile by remember { mutableStateOf(prefs.getBoolean("private_profile", false)) }
        PreferenceToggle(stringResource(R.string.rechado_notifications), notifications) { notifications = it; prefs.edit().putBoolean("notifications", it).apply() }
        PreferenceToggle(stringResource(R.string.rechado_autoplay), autoplay) { autoplay = it; prefs.edit().putBoolean("autoplay", it).apply() }
        PreferenceToggle(stringResource(R.string.rechado_private_profile), privateProfile) { privateProfile = it; prefs.edit().putBoolean("private_profile", it).apply() }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.rechado_ads_note), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun PreferenceToggle(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onToggle(!checked) }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Text(if (checked) "●" else "○", color = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
