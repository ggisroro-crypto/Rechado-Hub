package dev.anilbeesetti.nextplayer.navigation

import androidx.compose.runtime.mutableIntStateOf
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import dev.anilbeesetti.nextplayer.RechadoPreferencesRoute
import org.junit.Assert.assertEquals
import org.junit.Test

class TopLevelNavigationTest {

    @Test
    fun topLevelDestinationsAreInOrder() {
        assertEquals(
            listOf(
                TopLevelDestination.HOME,
                TopLevelDestination.VIDEOS,
                TopLevelDestination.COMMUNITY,
                TopLevelDestination.DELTA,
                TopLevelDestination.ACCOUNT,
            ),
            TopLevelDestination.entries,
        )
    }

    @Test
    fun switchingTabsPreservesAccountSettingsStack() {
        val stacks = TopLevelDestination.entries.associate { destination ->
            destination.route to NavBackStack<NavKey>(destination.route)
        }
        val state = TopLevelNavState(
            destinations = TopLevelDestination.entries,
            backStacks = stacks,
            selectedIndexState = mutableIntStateOf(0),
        )
        val accountStack = stacks.getValue(TopLevelDestination.ACCOUNT.route)

        state.switchTo(TopLevelDestination.ACCOUNT.route)
        accountStack += RechadoPreferencesRoute
        state.switchTo(TopLevelDestination.HOME.route)
        state.switchTo(TopLevelDestination.ACCOUNT.route)

        assertEquals(
            listOf(TopLevelDestination.ACCOUNT.route, RechadoPreferencesRoute),
            state.currentStack,
        )
    }

    @Test
    fun topLevelContentKeysContainsDestinations() {
        val stacks = TopLevelDestination.entries.associate { destination ->
            destination.route to NavBackStack<NavKey>(destination.route)
        }
        val state = TopLevelNavState(
            destinations = TopLevelDestination.entries,
            backStacks = stacks,
            selectedIndexState = mutableIntStateOf(0),
        )
        for (dest in TopLevelDestination.entries) {
            assert(state.topLevelContentKeys.contains(dest.route))
            assert(state.topLevelContentKeys.contains(Pair("${dest.route}", "${dest.route::class}")))
        }
    }
}
