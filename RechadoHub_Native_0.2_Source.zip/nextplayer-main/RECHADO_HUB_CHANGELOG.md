# Rechado Hub — base nativa 0.2

Esta adaptación parte de Next Player, un reproductor Android de código abierto licenciado bajo GPL-3.0. Se mantiene el archivo LICENSE y el código original relevante. Revisa LICENSE y README antes de redistribuir.

Cambios realizados en esta base:
- Nombre, identificador Android y versión inicial propios de Rechado Hub.
- Navegación principal: Inicio, Videos, Comunidad, Delta y Cuenta.
- Pantalla de inicio con diseño tipo feed de video, categorías y tarjetas de demostración. Las tarjetas abren la biblioteca local; no representan videos remotos reales.
- Sección Comunidad con publicaciones y likes de demostración, no sincronizados.
- Zona Roblox Delta con accesos oficiales y advertencias de seguridad.
- Perfil local con selector de foto, nombre visible y espera local de siete días para volver a cambiarlo.
- Ajustes de tema rojo/negro, claro y oscuro; selección de idioma (español, inglés y portugués); preferencias locales y frecuencia objetivo de anuncios.
- Colores dinámicos del sistema desactivados para conservar la marca.

Limitaciones reales de esta versión:
- No tiene backend: cuentas, seguidores, mensajes, perfiles verificados, comentarios públicos y sincronización multi-dispositivo aún no existen.
- El feed no trae videos online; la pestaña Videos conserva el reproductor de archivos del dispositivo del proyecto base. La integración de contenido de terceros debe respetar APIs, términos y licencias.
- La frecuencia publicitaria se guarda como preferencia, pero no hay red de anuncios integrada ni garantiza intervalos de 20 horas.
- El idioma cambia el locale de la app con AppCompat; algunas pantallas del proyecto original pueden tener cobertura de traducción distinta.
- Aún debe compilarse, instalarse y probarse en un entorno Android Studio con SDK. En el entorno usado para preparar estos archivos no hay Android SDK ni acceso de red para descargar Gradle, por lo que no se ha podido generar/verificar un APK aquí.
